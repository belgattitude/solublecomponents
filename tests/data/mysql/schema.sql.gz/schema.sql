-- MySQL dump 10.14  Distrib 5.5.33a-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: phpunit_soluble_test_db
-- ------------------------------------------------------
-- Server version	5.5.33a-MariaDB-1~raring-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `media_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `container_id` bigint(20) unsigned NOT NULL,
  `mimetype` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` bigint(20) unsigned DEFAULT NULL,
  `filemtime` int(10) unsigned DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `deleted_at` datetime DEFAULT NULL COMMENT 'Record deletion date',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`media_id`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`),
  KEY `IDX_6A2CA10CBC21F742` (`container_id`),
  KEY `title_idx` (`title`),
  KEY `description_idx` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=355 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Media table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `media_container`
--

DROP TABLE IF EXISTS `media_container`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media_container` (
  `container_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `folder` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `deleted_at` datetime DEFAULT NULL COMMENT 'Record deletion date',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`container_id`),
  UNIQUE KEY `unique_folder_idx` (`folder`),
  UNIQUE KEY `unique_reference_idx` (`reference`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`),
  KEY `title_idx` (`title`),
  KEY `description_idx` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Media container table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `product_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `brand_id` int(10) unsigned DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Reference',
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique slug for this record',
  `title` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invoice_title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(15000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `characteristic` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `volume` decimal(12,6) DEFAULT NULL COMMENT 'Volume per sales unit in m3',
  `weight` decimal(12,6) DEFAULT NULL COMMENT 'Weight per sales unit in Kg',
  `length` decimal(12,6) DEFAULT NULL COMMENT 'Length per sales unit in meter',
  `height` decimal(12,6) DEFAULT NULL COMMENT 'Heigth per sales unit in meter',
  `width` decimal(12,6) DEFAULT NULL COMMENT 'Width per sales unit in meter',
  `barcode_ean13` varchar(13) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'EAN 13 barcode',
  `flag_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Whether the product is active in public website',
  `activated_at` date DEFAULT NULL COMMENT 'Date on which product was actived/available',
  `icon_class` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `deleted_at` datetime DEFAULT NULL COMMENT 'Record deletion date',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `unique_reference_idx` (`reference`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`),
  UNIQUE KEY `unique_slug_idx` (`slug`),
  KEY `IDX_D34A04AD44F5D008` (`brand_id`),
  KEY `IDX_D34A04ADFE54D947` (`group_id`),
  KEY `IDX_D34A04AD12469DE2` (`category_id`),
  KEY `IDX_D34A04ADC54C8C93` (`type_id`),
  KEY `IDX_D34A04ADF8BD700D` (`unit_id`),
  KEY `title_idx` (`title`),
  KEY `description_idx` (`description`(255)),
  KEY `characteristic_idx` (`characteristic`),
  KEY `keywords_idx` (`keywords`)
) ENGINE=InnoDB AUTO_INCREMENT=2013040003 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Product table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_brand`
--

DROP TABLE IF EXISTS `product_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_brand` (
  `brand_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Reference',
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique slug for this record',
  `title` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(15000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flag_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Whether the brand is active in public website',
  `icon_class` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`brand_id`),
  UNIQUE KEY `unique_reference_idx` (`reference`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`),
  UNIQUE KEY `unique_title_idx` (`title`),
  UNIQUE KEY `unique_slug_idx` (`slug`),
  KEY `description_idx` (`description`(255))
) ENGINE=InnoDB AUTO_INCREMENT=295 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Product brand table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_category` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `reference` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(15000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_index` int(11) DEFAULT NULL,
  `icon_class` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) unsigned NOT NULL,
  `rgt` int(10) unsigned NOT NULL,
  `root` bigint(20) unsigned DEFAULT NULL,
  `lvl` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `legacy_synchro_at` datetime DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `UNIQ_CDFC7356989D9B62` (`slug`),
  UNIQUE KEY `unique_reference_idx` (`reference`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`),
  KEY `IDX_CDFC7356727ACA70` (`parent_id`),
  KEY `title_idx` (`title`),
  KEY `description_idx` (`description`(255)),
  KEY `lft_idx` (`lft`),
  KEY `rgt_idx` (`rgt`)
) ENGINE=InnoDB AUTO_INCREMENT=1542 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Product category table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_category_translation`
--

DROP TABLE IF EXISTS `product_category_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_category_translation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary key',
  `category_id` int(10) unsigned NOT NULL,
  `lang` varchar(2) COLLATE utf8_unicode_ci NOT NULL COMMENT 'iso_631_1 language code 2 digits',
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique slug for this record',
  `title` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(15000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_translation_idx` (`category_id`,`lang`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`),
  KEY `IDX_1DAAB48712469DE2` (`category_id`),
  KEY `IDX_1DAAB48731098462` (`lang`),
  KEY `title_idx` (`title`),
  KEY `description_idx` (`description`(255)),
  KEY `slug_idx` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7682 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Product translation table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_group`
--

DROP TABLE IF EXISTS `product_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_group` (
  `group_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Reference',
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique slug for this record',
  `title` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(15000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flag_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Whether the group is active in public website',
  `icon_class` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `unique_reference_idx` (`reference`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`),
  UNIQUE KEY `unique_slug_idx` (`slug`),
  KEY `title_idx` (`title`),
  KEY `description_idx` (`description`(255))
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Product group table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_group_translation`
--

DROP TABLE IF EXISTS `product_group_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_group_translation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary key',
  `group_id` int(10) unsigned NOT NULL,
  `lang` varchar(2) COLLATE utf8_unicode_ci NOT NULL COMMENT 'iso_631_1 language code 2 digits',
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique slug for this record',
  `title` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(15000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_translation_idx` (`group_id`,`lang`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`),
  KEY `IDX_255468FDFE54D947` (`group_id`),
  KEY `IDX_255468FD31098462` (`lang`),
  KEY `title_idx` (`title`),
  KEY `description_idx` (`description`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Product group translation table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_media`
--

DROP TABLE IF EXISTS `product_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `media_id` bigint(20) unsigned NOT NULL,
  `type_id` int(10) unsigned NOT NULL,
  `flag_primary` tinyint(1) DEFAULT NULL,
  `sort_index` int(10) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_product_media_type_idx` (`product_id`,`media_id`,`type_id`),
  UNIQUE KEY `unique_product_type_flag_primary_idx` (`type_id`,`product_id`,`flag_primary`),
  KEY `IDX_CB70DA504584665A` (`product_id`),
  KEY `IDX_CB70DA50EA9FDD75` (`media_id`),
  KEY `IDX_CB70DA50C54C8C93` (`type_id`),
  KEY `sort_index_idx` (`sort_index`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Product media table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_media_type`
--

DROP TABLE IF EXISTS `product_media_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_media_type` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Reference',
  `title` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(15000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon_class` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`type_id`),
  UNIQUE KEY `unique_reference_idx` (`reference`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Product media type table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_type`
--

DROP TABLE IF EXISTS `product_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_type` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(60) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Reference',
  `title` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(15000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon_class` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`type_id`),
  UNIQUE KEY `unique_reference_idx` (`reference`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Product type table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_unit`
--

DROP TABLE IF EXISTS `product_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_unit` (
  `unit_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(10) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Universal reference, kg, m3...',
  `title` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flag_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Whether the unit is active',
  `icon_class` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL COMMENT 'Record creation timestamp',
  `updated_at` datetime DEFAULT NULL COMMENT 'Record last update timestamp',
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Creator name',
  `updated_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Last updater name',
  `legacy_mapping` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Unique reference of this record taken from legacy system',
  `legacy_synchro_at` datetime DEFAULT NULL COMMENT 'Last synchro timestamp',
  PRIMARY KEY (`unit_id`),
  UNIQUE KEY `unique_reference_idx` (`reference`),
  UNIQUE KEY `unique_legacy_mapping_idx` (`legacy_mapping`),
  KEY `title_idx` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Product unit table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `reference` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `UNIQ_57698A6AAEA34913` (`reference`),
  KEY `IDX_57698A6A727ACA70` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_table_collation`
--

DROP TABLE IF EXISTS `test_table_collation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_table_collation` (
  `id` int(10) unsigned NOT NULL,
  `test_iso` char(10) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `test_utf8` char(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_table_types`
--

DROP TABLE IF EXISTS `test_table_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_table_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_varchar_255` varchar(255) NOT NULL,
  `test_char_10` char(10) NOT NULL,
  `test_text_2000` text NOT NULL,
  `test_binary_3` binary(3) NOT NULL,
  `test_varbinary_10` varbinary(10) NOT NULL,
  `test_int_unsigned` int(10) unsigned NOT NULL,
  `test_bigint` bigint(20) NOT NULL,
  `test_decimal_10_3` decimal(10,3) NOT NULL,
  `test_float` float NOT NULL,
  `test_tinyint` tinyint(4) NOT NULL,
  `test_mediumint` mediumint(9) NOT NULL,
  `test_double` double NOT NULL,
  `test_smallint` smallint(6) NOT NULL,
  `test_date` date NOT NULL,
  `test_datetime` datetime NOT NULL,
  `test_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `test_time` time NOT NULL,
  `test_blob` blob NOT NULL,
  `test_tinyblob` tinyblob NOT NULL,
  `test_mediumblob` mediumblob NOT NULL,
  `test_longblob` longblob NOT NULL,
  `test_enum` enum('M','F') NOT NULL,
  `test_set` set('M','F') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_table_without_pk`
--

DROP TABLE IF EXISTS `test_table_without_pk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_table_without_pk` (
  `test_field` int(11) DEFAULT NULL,
  `test_field2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `displayName` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `IDX_2DE8C6A3A76ED395` (`user_id`),
  KEY `IDX_2DE8C6A3D60322AC` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'phpunit_soluble_test_db'
--

--
-- Dumping routines for database 'phpunit_soluble_test_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-10-10 11:30:11
